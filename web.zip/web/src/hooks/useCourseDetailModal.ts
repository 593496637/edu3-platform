import { useCourseDetailModal } from '../contexts/CourseDetailContext';

export { useCourseDetailModal };
