import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { apiRequest, type Course, type Purchase } from '../lib/contracts';

// 钱包登录hook
export const useWalletAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { address } = useAccount();

  useEffect(() => {
    // 检查本地存储的token
    const token = localStorage.getItem('auth_token');
    const tokenAddress = localStorage.getItem('auth_address');
    
    if (token && tokenAddress && tokenAddress.toLowerCase() === address?.toLowerCase()) {
      setAuthToken(token);
      setIsAuthenticated(true);
    } else {
      // 清除过期或不匹配的token
      localStorage.removeItem('auth_token');
      localStorage.removeItem('auth_address');
      setIsAuthenticated(false);
      setAuthToken(null);
    }
  }, [address]);

  const login = async (address: string, message: string, signature: string) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ address, message, signature }),
      });

      if (response.success) {
        const { token } = response.data;
        setAuthToken(token);
        setIsAuthenticated(true);
        
        // 保存到本地存储
        localStorage.setItem('auth_token', token);
        localStorage.setItem('auth_address', address.toLowerCase());
        
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setAuthToken(null);
    setIsAuthenticated(false);
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_address');
  };

  return {
    isAuthenticated,
    authToken,
    isLoading,
    login,
    logout,
  };
};

// 课程数据hook
export const useCourses = (filters?: {
  instructorAddress?: string;
  category?: string;
  difficulty?: string;
  search?: string;
  page?: number;
  limit?: number;
}) => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCourses = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // 构建查询参数
      const params = new URLSearchParams();
      if (filters?.instructorAddress) params.set('instructorAddress', filters.instructorAddress);
      if (filters?.category) params.set('category', filters.category);
      if (filters?.difficulty) params.set('difficulty', filters.difficulty);
      if (filters?.search) params.set('search', filters.search);
      if (filters?.page) params.set('page', filters.page.toString());
      if (filters?.limit) params.set('limit', filters.limit.toString());

      const endpoint = `/courses${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await apiRequest(endpoint);
      if (response.success) {
        setCourses(response.data.courses);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch courses');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [
    filters?.instructorAddress,
    filters?.category, 
    filters?.difficulty,
    filters?.search,
    filters?.page,
    filters?.limit
  ]);

  return {
    courses,
    isLoading,
    error,
    refetch: fetchCourses,
  };
};

// 用户购买记录hook
export const useUserPurchases = (address?: string) => {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPurchases = async () => {
    if (!address) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/users/${address}/purchases`);
      if (response.success) {
        setPurchases(response.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch purchases');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (address) {
      fetchPurchases();
    }
  }, [address]);

  return {
    purchases,
    isLoading,
    error,
    refetch: fetchPurchases,
  };
};

// 余额查询hook
export const useBalance = (address?: string) => {
  const [balance, setBalance] = useState<string>('0');
  const [balanceFormatted, setBalanceFormatted] = useState<string>('0');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBalance = async () => {
    if (!address) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/blockchain/balance/${address}`);
      if (response.success) {
        setBalance(response.data.balance);
        setBalanceFormatted(response.data.balanceFormatted);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch balance');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (address) {
      fetchBalance();
    }
  }, [address]);

  return {
    balance,
    balanceFormatted,
    isLoading,
    error,
    refetch: fetchBalance,
  };
};

// 购买状态检查hook - 修复API路径
export const usePurchaseStatus = (courseId?: number, address?: string) => {
  const [hasPurchased, setHasPurchased] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkPurchaseStatus = async () => {
    if (!courseId || !address) return;
    
    setIsLoading(true);
    setError(null);
    try {
      // 修复: 添加缺失的 /courses 路径段
      const response = await apiRequest(`/blockchain/courses/${courseId}/purchased/${address}`);
      if (response.success) {
        setHasPurchased(response.data.hasPurchased);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to check purchase status');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (courseId && address) {
      checkPurchaseStatus();
    }
  }, [courseId, address]);

  return {
    hasPurchased,
    isLoading,
    error,
    refetch: checkPurchaseStatus,
  };
};

// 讲师状态检查hook
export const useInstructorStatus = (address?: string) => {
  const [isInstructor, setIsInstructor] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkInstructorStatus = async () => {
    if (!address) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/blockchain/instructor/${address}`);
      if (response.success) {
        setIsInstructor(response.data.isInstructor);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to check instructor status');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (address) {
      checkInstructorStatus();
    }
  }, [address]);

  return {
    isInstructor,
    isLoading,
    error,
    refetch: checkInstructorStatus,
  };
};

// 购买验证hook
export const usePurchaseVerification = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const verifyPurchase = async (txHash: string, courseId: number, userAddress: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest('/purchases/verify', {
        method: 'POST',
        body: JSON.stringify({ txHash, courseId, userAddress }),
      });

      if (response.success) {
        return response.data;
      }
      return null;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to verify purchase';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    verifyPurchase,
    isLoading,
    error,
  };
};

// 讲师仪表盘统计数据hook
export const useInstructorDashboard = (address?: string) => {
  const [dashboardData, setDashboardData] = useState<{
    overview: {
      totalCourses: number;
      totalStudents: number;
      totalEarnings: number;
      averageRating: number;
    };
    courseStats: Array<{
      id: string;
      title: string;
      enrollmentCount: number;
      reviewCount: number;
      lessonCount: number;
      averageRating: number;
    }>;
    recentActivity: {
      lastUpdated: string;
    };
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardData = async () => {
    if (!address) return;
    
    setIsLoading(true);
    setError(null);
    try {
      // 传递地址参数给API
      const response = await apiRequest(`/users/instructor/dashboard?address=${address}`);
      if (response.success) {
        setDashboardData(response.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (address) {
      fetchDashboardData();
    }
  }, [address]);

  return {
    dashboardData,
    isLoading,
    error,
    refetch: fetchDashboardData,
  };
};

// 课程详情hook（根据链上ID查询）
export const useCourseDetail = (courseId?: string | number) => {
  const [course, setCourse] = useState<Course | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCourseDetail = async () => {
    if (!courseId) return;
    
    setIsLoading(true);
    setError(null);
    try {
      // 使用新的根据链上ID查询的接口
      const response = await apiRequest(`/courses/by-chain-id/${courseId}`);
      if (response.success) {
        setCourse(response.data);
      } else {
        const errorMsg = response.error || 'API returned unsuccessful response';
        console.error('Failed to fetch course details:', errorMsg);
        setError(errorMsg);
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to fetch course details';
      console.error('Failed to fetch course details:', err);
      setError(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log('🔄 useCourseDetail effect triggered with courseId:', courseId);
    if (courseId) {
      console.log('📡 Starting API call for courseId:', courseId);
      fetchCourseDetail();
    } else {
      console.log('❌ No courseId provided, skipping API call');
      setCourse(null);
      setError(null);
    }
  }, [courseId]);

  return {
    course,
    isLoading,
    error,
    refetch: fetchCourseDetail,
  };
};

// 添加创建课程的 hook
export const useCourseCreation = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createCourse = async (courseData: {
    title: string;
    description: string;
    content?: string;
    price: string;
    duration?: string;
    difficulty?: string;
    category: string;
    tags?: string[];
    requirements?: string[];
    objectives?: string[];
    thumbnail?: string;
    onChainId?: number;
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest('/courses', {
        method: 'POST',
        body: JSON.stringify(courseData),
      });

      if (response.success) {
        return response.data;
      }
      return null;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create course';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const updateCourse = async (courseId: number, courseData: Partial<{
    title: string;
    description: string;
    content: string;
    price: string;
    duration: string;
    difficulty: string;
    category: string;
    tags: string[];
    requirements: string[];
    objectives: string[];
    thumbnail: string;
  }>) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/courses/${courseId}`, {
        method: 'PUT',
        body: JSON.stringify(courseData),
      });

      if (response.success) {
        return response.data;
      }
      return null;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update course';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteCourse = async (courseId: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest(`/courses/${courseId}`, {
        method: 'DELETE',
      });

      if (response.success) {
        return response.data;
      }
      return null;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete course';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    createCourse,
    updateCourse,
    deleteCourse,
    isLoading,
    error,
  };
};
