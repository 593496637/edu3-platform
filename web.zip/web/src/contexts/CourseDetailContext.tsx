import { createContext, useContext, useState } from 'react';
import type { ReactNode } from 'react';

interface CourseDetailContextType {
  isOpen: boolean;
  courseId: string | number | null;
  openCourseDetail: (courseId: string | number) => void;
  closeCourseDetail: () => void;
}

const CourseDetailContext = createContext<CourseDetailContextType | undefined>(undefined);

interface CourseDetailProviderProps {
  children: ReactNode;
}

export function CourseDetailProvider({ children }: CourseDetailProviderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [courseId, setCourseId] = useState<string | number | null>(null);

  const openCourseDetail = (id: string | number) => {
    console.log('🚀 CourseDetailContext: openCourseDetail called with id:', id);
    console.log('🚀 Setting courseId and opening modal...');
    setCourseId(id);
    setIsOpen(true);
    console.log('🚀 Modal state updated:', { courseId: id, isOpen: true });
  };

  const closeCourseDetail = () => {
    console.log('🔒 CourseDetailContext: closeCourseDetail called');
    setIsOpen(false);
    // 延迟清除courseId，等待动画完成
    setTimeout(() => {
      setCourseId(null);
      console.log('🔒 CourseId cleared after animation');
    }, 300);
  };

  const value = {
    isOpen,
    courseId,
    openCourseDetail,
    closeCourseDetail,
  };

  return (
    <CourseDetailContext.Provider value={value}>
      {children}
    </CourseDetailContext.Provider>
  );
}

export function useCourseDetailModal() {
  const context = useContext(CourseDetailContext);
  if (context === undefined) {
    throw new Error('useCourseDetailModal must be used within a CourseDetailProvider');
  }
  return context;
}
