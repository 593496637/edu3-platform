import React from 'react';
import type { CourseFormData, ValidationErrors } from '../utils/courseValidation';

interface CreateCourseFormProps {
  formData: CourseFormData;
  errors: ValidationErrors;
  onInputChange: (field: keyof CourseFormData, value: string) => void;
}

export default function CreateCourseForm({ 
  formData, 
  errors, 
  onInputChange 
}: CreateCourseFormProps) {
  return (
    <div className="space-y-6">
      {/* 课程标题 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          课程标题 *
        </label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => onInputChange('title', e.target.value)}
          className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
            errors.title ? 'border-red-300' : 'border-gray-300'
          }`}
          placeholder="输入课程标题"
        />
        {errors.title && (
          <p className="mt-1 text-sm text-red-600">{errors.title}</p>
        )}
      </div>

      {/* 课程内容 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          课程内容 *
        </label>
        <textarea
          value={formData.content}
          onChange={(e) => onInputChange('content', e.target.value)}
          rows={8}
          className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
            errors.content ? 'border-red-300' : 'border-gray-300'
          }`}
          placeholder="详细的课程内容，支持Markdown格式"
        />
        {errors.content && (
          <p className="mt-1 text-sm text-red-600">{errors.content}</p>
        )}
      </div>

      {/* 价格 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          价格 (YD币) *
        </label>
        <input
          type="number"
          value={formData.price}
          onChange={(e) => onInputChange('price', e.target.value)}
          className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
            errors.price ? 'border-red-300' : 'border-gray-300'
          }`}
          placeholder="例如: 100"
          min="0"
          step="1"
        />
        {errors.price && (
          <p className="mt-1 text-sm text-red-600">{errors.price}</p>
        )}
      </div>
    </div>
  );
}