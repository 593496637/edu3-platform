import { useState, useEffect } from 'react';
import {
  useAccount,
  useWriteContract,
  useWaitForTransactionReceipt,
} from 'wagmi';
import {
  Clock,
  Users,
  Star,
  ShoppingCart,
  BookOpen,
  CheckCircle,
  Loader2,
  Play,
  AlertCircle,
} from 'lucide-react';
import Modal from './Modal';
import { useCourseDetailModal } from '../contexts/CourseDetailContext';
import { useCourseDetail, usePurchaseStatus, usePurchaseVerification, useBalance } from '../hooks/useApi';
import { CONTRACTS, COURSE_PLATFORM_ABI, YD_TOKEN_ABI } from '../lib/contracts';

interface PurchaseState {
  step: 'idle' | 'approving' | 'approved' | 'purchasing' | 'verifying' | 'completed' | 'error';
  error?: string;
}

export default function CourseDetailModal() {
  const { isOpen, courseId, closeCourseDetail } = useCourseDetailModal();
  const { address, isConnected } = useAccount();
  const [purchaseState, setPurchaseState] = useState<PurchaseState>({ step: 'idle' });

  // 调试日志 - 验证modal状态
  console.log('🪟 CourseDetailModal render:', { 
    isOpen, 
    courseId, 
    courseIdType: typeof courseId,
    courseIdValid: courseId !== null && courseId !== undefined,
    timestamp: new Date().toISOString() 
  });

  // 获取课程详情 - 只有当modal打开且有courseId时才调用
  const shouldFetchCourse = isOpen && courseId !== null && courseId !== undefined;
  console.log('🔍 Should fetch course:', shouldFetchCourse, { isOpen, courseId });
  
  const { course, isLoading: courseLoading, error: courseError } = useCourseDetail(shouldFetchCourse ? courseId : undefined);
  
  // 调试课程数据
  console.log('📚 Course data:', { 
    course, 
    courseLoading, 
    courseError, 
    hasCourseId: !!courseId,
    courseTitle: course?.title || 'No course data'
  });
  
  // 获取用户余额
  const { balanceFormatted } = useBalance(address);
  
  // 检查购买状态
  const { hasPurchased } = usePurchaseStatus(
    course?.chain_id,
    address
  );

  // 购买验证
  const { verifyPurchase } = usePurchaseVerification();

  // 授权YD代币
  const {
    writeContract: approveTokens,
    data: approveHash,
    reset: resetApprove,
  } = useWriteContract();

  // 购买课程
  const {
    writeContract: buyCourse,
    data: buyHash,
    reset: resetBuy,
  } = useWriteContract();

  // 等待交易确认
  const { 
    isSuccess: isApproveSuccess,
    isError: isApproveError,
  } = useWaitForTransactionReceipt({
    hash: approveHash,
  });

  const { 
    isSuccess: isBuySuccess,
    isError: isBuyError,
  } = useWaitForTransactionReceipt({
    hash: buyHash,
  });

  // 处理approve成功后自动购买
  useEffect(() => {
    if (isApproveSuccess && purchaseState.step === 'approving' && course) {
      setPurchaseState({ step: 'approved' });
      
      // 自动执行购买
      setTimeout(() => {
        const courseChainId = course.chain_id;
        if (courseChainId) {
          buyCourse({
            address: CONTRACTS.CoursePlatform,
            abi: COURSE_PLATFORM_ABI,
            functionName: "buyCourse",
            args: [BigInt(courseChainId)],
          });
          setPurchaseState({ step: 'purchasing' });
        }
      }, 1000);
    }
  }, [isApproveSuccess, purchaseState, buyCourse, course]);

  // 处理购买成功后验证交易
  useEffect(() => {
    if (isBuySuccess && purchaseState.step === 'purchasing' && buyHash && course && address) {
      setPurchaseState({ step: 'verifying' });
      
      const courseChainId = course.chain_id;
      if (courseChainId) {
        // 验证并记录购买交易
        verifyPurchase(buyHash, courseChainId, address)
          .then(() => {
            setPurchaseState({ step: 'completed' });
            // 3秒后重置状态
            setTimeout(() => {
              setPurchaseState({ step: 'idle' });
            }, 3000);
          })
          .catch((error) => {
            setPurchaseState({ 
              step: 'error', 
              error: error.message 
            });
          });
      }
    }
  }, [isBuySuccess, purchaseState, buyHash, address, verifyPurchase, course]);

  // 处理交易错误
  useEffect(() => {
    if (isApproveError || isBuyError) {
      setPurchaseState({ 
        step: 'error', 
        error: isApproveError ? '代币授权失败' : '购买交易失败'
      });
      // 5秒后重置状态
      setTimeout(() => {
        setPurchaseState({ step: 'idle' });
      }, 5000);
    }
  }, [isApproveError, isBuyError]);

  const handlePurchase = async () => {
    if (!isConnected || !course) return;
    
    // 重置状态
    resetApprove();
    resetBuy();
    setPurchaseState({ step: 'approving' });
    
    try {
      // 先授权代币
      approveTokens({
        address: CONTRACTS.YDToken,
        abi: YD_TOKEN_ABI,
        functionName: "approve",
        args: [CONTRACTS.CoursePlatform, BigInt(course.price)],
      });
    } catch (error) {
      setPurchaseState({ 
        step: 'error', 
        error: error instanceof Error ? error.message : '授权失败'
      });
    }
  };


  // 重置购买状态当modal关闭时
  useEffect(() => {
    if (!isOpen) {
      setPurchaseState({ step: 'idle' });
      resetApprove();
      resetBuy();
    }
  }, [isOpen, resetApprove, resetBuy]);

  const renderPurchaseButton = () => {
    if (!isConnected) {
      return (
        <button className="w-full rounded-lg bg-gray-400 px-6 py-3 font-medium text-white cursor-not-allowed">
          请先连接钱包
        </button>
      );
    }

    if (hasPurchased) {
      return (
        <button className="w-full flex items-center justify-center rounded-lg bg-green-600 px-6 py-3 font-medium text-white">
          <CheckCircle className="mr-2 h-5 w-5" />
          已购买
        </button>
      );
    }

    switch (purchaseState.step) {
      case 'approving':
        return (
          <button
            disabled
            className="w-full flex items-center justify-center rounded-lg bg-yellow-600 px-6 py-3 font-medium text-white"
          >
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            授权中...
          </button>
        );
      case 'approved':
        return (
          <button
            disabled
            className="w-full flex items-center justify-center rounded-lg bg-blue-600 px-6 py-3 font-medium text-white"
          >
            <CheckCircle className="mr-2 h-5 w-5" />
            授权成功
          </button>
        );
      case 'purchasing':
        return (
          <button
            disabled
            className="w-full flex items-center justify-center rounded-lg bg-orange-600 px-6 py-3 font-medium text-white"
          >
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            购买中...
          </button>
        );
      case 'verifying':
        return (
          <button
            disabled
            className="w-full flex items-center justify-center rounded-lg bg-purple-600 px-6 py-3 font-medium text-white"
          >
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            验证中...
          </button>
        );
      case 'completed':
        return (
          <button
            disabled
            className="w-full flex items-center justify-center rounded-lg bg-green-600 px-6 py-3 font-medium text-white"
          >
            <CheckCircle className="mr-2 h-5 w-5" />
            购买成功！
          </button>
        );
      case 'error':
        return (
          <button
            onClick={() => setPurchaseState({ step: 'idle' })}
            className="w-full flex items-center justify-center rounded-lg bg-red-600 px-6 py-3 font-medium text-white hover:bg-red-700"
          >
            <AlertCircle className="mr-2 h-5 w-5" />
            {purchaseState.error} - 点击重试
          </button>
        );
      default: {
        const price = course?.priceformatted || course?.price || '0';
        return (
          <button
            onClick={handlePurchase}
            className="w-full flex items-center justify-center rounded-lg bg-blue-600 px-6 py-3 font-medium text-white hover:bg-blue-700"
          >
            <ShoppingCart className="mr-2 h-5 w-5" />
            购买课程 - {price} YD
          </button>
        );
      }
    }
  };

  // 如果modal没有打开，不渲染任何内容
  if (!isOpen) {
    console.log('🚫 Modal not open, not rendering');
    return null;
  }

  console.log('🖼️ Rendering modal with state:', { isOpen, courseId, courseLoading, courseError, hasCourse: !!course });

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={closeCourseDetail}
      size="xl"
      title="课程详情"
    >
      <div className="p-6">

        {courseLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            <span className="ml-2 text-gray-600">加载课程信息中...</span>
          </div>
        ) : courseError ? (
          <div className="text-center py-12">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">加载失败</h3>
            <p className="text-gray-600">{courseError}</p>
            <div className="mt-4 text-sm text-gray-500">
              尝试的CourseId: {courseId}
            </div>
          </div>
        ) : course ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* 左侧主要内容 */}
            <div className="lg:col-span-2 space-y-6">
              {/* 课程头部信息 */}
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{course.title}</h1>
                <p className="text-gray-600 mb-4">{course.description}</p>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Star className="mr-1 h-4 w-4 text-yellow-400" />
                    <span className="font-medium">4.8</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="mr-1 h-4 w-4" />
                    <span>156 学员</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="mr-1 h-4 w-4" />
                    <span>{course.duration || '20小时'}</span>
                  </div>
                  {course.difficulty && (
                    <div className="rounded-full bg-green-100 px-2 py-1 text-green-800">
                      {course.difficulty}
                    </div>
                  )}
                </div>
              </div>

              {/* 学习目标 */}
              {course.objectives && course.objectives.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">你将学到什么</h3>
                  <div className="grid grid-cols-1 gap-2">
                    {course.objectives.map((objective, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <CheckCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500" />
                        <span className="text-gray-700">{objective}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 课程要求 */}
              {course.requirements && course.requirements.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">课程要求</h3>
                  <ul className="space-y-2">
                    {course.requirements.map((requirement, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="mt-2 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-gray-400"></div>
                        <span className="text-gray-700">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* 右侧购买卡片 */}
            <div className="lg:col-span-1">
              <div className="sticky top-0 space-y-6">
                {/* 课程预览 */}
                <div className="aspect-video rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                  <Play className="h-12 w-12 text-white" />
                </div>

                {/* 价格 */}
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    {course.priceformatted || course.price || '100'} YD
                  </div>
                  <div className="text-sm text-gray-500">一次购买，终身学习</div>
                  
                  {/* 讲师信息 */}
                  {(course.instructor || course.instructor_address) && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600">讲师</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="font-medium text-gray-900">
                          {course.instructor?.username || 
                           course.instructor?.address?.slice(0, 6) + '...' + course.instructor?.address?.slice(-4) ||
                           course.instructor_address?.slice(0, 6) + '...' + course.instructor_address?.slice(-4)}
                        </div>
                      </div>
                      {course.instructor?.bio && (
                        <div className="text-xs text-gray-500 mt-1">{course.instructor.bio}</div>
                      )}
                    </div>
                  )}
                </div>

                {/* 购买按钮 */}
                <div className="space-y-4">
                  {renderPurchaseButton()}
                  
                  {/* 余额显示 */}
                  {isConnected && (
                    <div className="rounded-lg bg-gray-50 p-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">您的YD余额:</span>
                        <span className="font-medium">{balanceFormatted || '0'} YD</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* 包含内容 */}
                <div className="space-y-3 border-t pt-6">
                  <h4 className="font-medium text-gray-900">此课程包含:</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4" />
                      <span>{course.duration || '20小时'} 点播视频</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <BookOpen className="h-4 w-4" />
                      <span>完整课程内容</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4" />
                      <span>终身访问</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4" />
                      <span>完成证书</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">课程信息不可用</h3>
            <p className="text-gray-600">
              {courseId ? `无法找到课程ID ${courseId} 的信息` : '没有提供课程ID'}
            </p>
            <button
              onClick={closeCourseDetail}
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              关闭
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
}
