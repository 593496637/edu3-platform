export { default as HomePage } from './HomePage';
export { default as ExchangePage } from './ExchangePage';
export { default as InstructorPage } from './InstructorPage';
export { default as MyCoursesPage } from './MyCoursesPage';
export { default as ProfilePage } from './ProfilePage';
export { default as CourseDetailPage } from './CourseDetailPage';
export { default as CourseLearnPage } from './CourseLearnPage';
export { default as AdminPage } from './AdminPage';
